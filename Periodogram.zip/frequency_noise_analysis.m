% generates frequency maps and noise quantification included in
% Soto & Biga et al. (2020) EMBO J , Figure EV4 
clear all,close all, clc
Lengthscale =2.5; % was 2.5 
DetrendParam = log(1./(2*Lengthscale.^2));
type='psd';
sheet='Venus norm by H2B';%'Venus norm by H2B'; % alternatively use 'H2B' 
dirname=sheet;
%%
% CTRL data norm by H2B- full data
num=xlsread('CTRL 34hpf 240118.xls',sheet);
num(isnan(num))=0;
data=num(:,2:16);
time=num(:,1);
PSpec=[];
Fs = 1/(time(2)-time(1)); % Hz 1/h
f = 0:Fs/100:Fs/2; % corresponding to 12h % was 148
% enhance individual figures to add background
s1=[];
figure
for i=1:size(data,2)
    x=time;
    vect=data(:,i);
    x(vect==0)=[]; vect(vect==0)=[];
    % detrend data here
    [m,m1,par0] = detrenddataNEW(vect,x,DetrendParam);
    vect=vect-m;
    s1=[s1 std(vect)];
    vect=vect/std(vect);
    % compute power spectrum
    [pxx,fx]=periodogram(vect,[],f,Fs,type);
    %[pxx,fx] = plomb(vect,x,f,type);
    PSpec(i,:)=pxx';
    subplot(5,3,i)
    plot(fx,pxx,'b');
    xlabel('Frequency (1/hours)')
    ylabel('PSD')
    title(['Cell no. ' num2str(i)])
    hold on
end
PSpec_CTRL=PSpec;
title('Periodogram-CTRL')
clear PSpec
%% MBS normalised by H2B
num=xlsread('MBS 34hpf 240118.xls',sheet);
num(isnan(num))=0;
data=num(:,2:15);
time=num(:,1);
PSpec=[];
Fs = 1/(time(2)-time(1)); % Hz 1/h
f = 0:Fs/100:Fs/2; % corresponding to 12h % was 148
% enhance individual figures to add background
figure
for i=1:size(data,2)
    x=time;
    vect=data(:,i);
    x(vect==0)=[]; vect(vect==0)=[];
    % detrend data here
    [m,m1,par0] = detrenddataNEW(vect,x,DetrendParam);
    vect=vect-m;
    s1=[s1 std(vect)];
    vect=vect/std(vect);
    % compute power spectrum
    [pxx,fx]=periodogram(vect,[],f,Fs,type);
    %[pxx,fx] = plomb(vect,x,f,type);
    PSpec(i,:)=pxx';
    subplot(5,3,i)
    plot(fx,pxx,'b');
    xlabel('Frequency (1/hours)')
    ylabel('PSD')
    title(['Cell no. ' num2str(i)])
    hold on
end
PSpec_MBS=PSpec;
title('Periodogram-MBS')
clear PSpec
%% Background data
switch sheet
    case 'Venus norm by H2B'
        bkgr_idx=[18,19];
    otherwise
        bkgr_idx=[16,17];
end
bkgr=num(4:end,bkgr_idx); % corresponding to Venus 
PSpec=[];
Fs = 1/(time(2)-time(1)); % Hz 1/h
f = 0:Fs/100:Fs/2; % corresponding to 12h % was 148
for i=1:size(bkgr,2)
    % detrending or not detrending
    vect=bkgr(:,i); % in relative intensity units
    x=time(1:numel(vect)); x(isnan(vect))=[];
    vect(isnan(vect))=[];
    [m,par0]=detrenddataNEW(vect,x,DetrendParam);
    vect=vect-m;
    vect=vect/mean(s1);
    % compute power spectrum
    [pxx,fx]=periodogram(vect,[],f,Fs,type);
    PSpec(i,:)=pxx';
end
% combined spectra
PSpec_combined=[PSpec_CTRL;PSpec_MBS; PSpec];
figure(100),imagesc(PSpec_combined),title('CTRL & MBS 240118');
set(gca,'YTick',[1:size(PSpec_combined,1)]);
hold on
line([0,60],[size(PSpec_CTRL,1)+0.5,size(PSpec_CTRL,1)+0.5],'LineWidth',2,'Color','k');
line([0,60],[size(PSpec_CTRL,1)+size(PSpec_MBS,1)+0.5,size(PSpec_CTRL,1)+size(PSpec_MBS,1)+0.5],'LineWidth',2,'Color','w');
ylabel('Cell no.');
yy=get(gca,'XTick');
set(gca,'XTickLabel',f(yy));
xlabel('Frequency (1/h)');
%% split the spectra into low and high frequency
th=find(f==1.5)
%% run single cell quantif from heatmap
clear ps
for i=1:size(PSpec_combined)-2
    vect=PSpec_combined(i,:);
    ps(i)=sum(vect(th:end))/sum(vect);
end
bob1=ps(1:15)*100;
bob2=[ps(16:end) NaN]*100;
figure,boxplot([bob1(:)  bob2(:)]);
set(gca,'XTickLabel',{'CTRL','MBS'});
ylabel('% High frequency contribution');
