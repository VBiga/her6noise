% generates aggregate spectra  included in
% Soto & Biga et al. (2020) EMBO J , Figure EV4 
clear all,close all, clc
Lengthscale =2.5; % was 2.5 
DetrendParam = log(1./(2*Lengthscale.^2));
type='power';
sheet='Venus norm by H2B'; % alternatively use 'H2B' 
dirname=sheet;
% CTRL data norm by H2B- full data
num=xlsread('CTRL 34hpf 240118.xls',sheet);
num(isnan(num))=0;
data=num(:,2:16);
time=num(:,1);
PSpec=[];
Fs = 1/(time(2)-time(1)); % Hz 1/h
f = 0:Fs/100:Fs/2; % corresponding to 12h % was 148
% enhance individual figures to add background
s1=[];
for i=1:size(data,2)
    x=time;
    vect=data(:,i);
    x(vect==0)=[]; vect(vect==0)=[];
    % detrend data here
    [m,m1,par0] = detrenddataNEW(vect,x,DetrendParam);
    vect=vect-m;
    s1=[s1 std(vect)];
    vect=vect/std(vect);
    % compute power spectrum
    [pxx,fx]=periodogram(vect,[],f,Fs,type);
    %[pxx,fx] = plomb(vect,x,f,type);
    PSpec(i,:)=pxx';
end
PSpec_CTRL=PSpec;
% average the power spectrum across the population
MeanPSDultrad=mean(PSpec);
figure(1),plot(f,MeanPSDultrad,'g','LineWidth',2);
hold on
%% MBS normalised by H2B
num=xlsread('MBS 34hpf 240118.xls',sheet);
num(isnan(num))=0;
data=num(:,2:15);
time=num(:,1);
PSpec=[];
Fs = 1/(time(2)-time(1)); % Hz 1/h
f = 0:Fs/100:Fs/2; % corresponding to 12h % was 148
% enhance individual figures to add background
for i=1:size(data,2)
    x=time;
    vect=data(:,i);
    x(vect==0)=[]; vect(vect==0)=[];
    % detrend data here
    [m,m1,par0] = detrenddataNEW(vect,x,DetrendParam);
    vect=vect-m;
    s1=[s1 std(vect)];
    vect=vect/std(vect);
    % compute power spectrum
    [pxx,fx]=periodogram(vect,[],f,Fs,type);
    %[pxx,fx] = plomb(vect,x,f,type);
    PSpec(i,:)=pxx';
end
PSpec_MBS=PSpec;
% average the power spectrum across the population
plot(f,mean(PSpec),'r','LineWidth',2);
xlabel('Frequency (1/h)');
ylabel('Power');
legend('CTRL','MBS');




