function h=showfigure1(x,m,raw,y1,xd,md,M1,S1,S2,LLR,par2,par1,i)
% adjust to fl intensity
m=m*S1;%+M1;
raw=raw*S1;%+M1;
y1=y1*S2*S1;
md=md*S2*S1;
%SHOWFIGURE Summary of this function goes here
%   Detailed explanation goes here
    % plots raw data with trend and detrended data
    h=figure();
    subplot(2,1,1)
    hold on
    plot(x,m,'r','LineWidth',2)
    plot(x,raw,'r','LineWidth',1.5);
    xlabel('Time (h)')
    ylabel('Her6::Venus/H2B')
    title(['Fluorescence intensity cell ' num2str(i)]);
    subplot(2,1,2)    
    plot(x,y1,'LineWidth',1.5)
    hold on
    plot(xd,md,'b','LineWidth',2)
    xlabel('Time (hours)')
    ylabel('Detrended Her6::Venus/H2B');
    aOU=round(par1(1)*100)/100;
    per=round(2*pi()/par2(2)*100)/100;
    llr=round(LLR*100)/100;
    if LLR<=0.01 %cap the display at small LLR
        title(['LLR score = ' num2str(llr) ', \alphaOU = ' num2str(aOU)]); 
    else
        title(['LLR score = ' num2str(llr) ', Period = ' num2str(per) 'h , \alphaOU=' num2str(aOU)]);
    end

