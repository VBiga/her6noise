addpath(genpath('GPML'))
startup
clear all, close all, clc
%% choose lengthscale to detrend (in hours)
Lengthscale =2.5; % roughly 3x period expected (in hours) 
DetrendParam = log(1./(2*Lengthscale.^2));
% %% 34hpf 240118 CTRL -Her6 div by H2B
% fnames='240118 CTRL HER6 norm by H2B.xls'; % raw data filename
% exptnames='240118 CTRL HER6 norm by H2B'; % analysis filename
% coldata=[2:16]; 
% bkgrdata=[19:20];
%% 34hpf 240118 MBS- Her6 div by H2B
fnames='240118 MBS HER6 norm by H2B.xls'; % raw data filename
exptnames='240118 MBS HER6 norm by H2B';% analysis filename
coldata=[2:15]; 
bkgrdata=[18:19];
%% generate new folder
dirname=[exptnames];
mkdir(dirname)
%% load data
num = xlsread(fnames);
num(isnan(num)) = 0;
data = num(4:end,coldata);
bckgd= num(4:end,bkgrdata);
time = num(4:end,1); % enter column of time always 1
time=time/(60*60);%convert from ms to hours
%
M1=zeros(1,size(data,2));
M2=zeros(1,size(data,2));
S1=zeros(1,size(data,2));
S2=zeros(1,size(data,2));
detrendData=[];
%% background SD
[stdev] = bckgdstdev(bckgd,time,-7); % this is around 0.1
parfor i = 1:size(data,2)
    i
    y1 =data(:,i);
    x = time;
    x(y1==0) = []; %deletes times from which no signal
    samp = length(x);
    y1(y1==0) = [];
    raw = y1;
    % store normalization constants
    M1(i)=mean(y1);
    S1(i)=std(y1);
    sd=stdev/std(y1);
    y1 = (y1 )/std(y1); 
    raw = y1;
    %detrending of the data
    [m,m1,par0] = detrenddataNEW(raw,x,DetrendParam);
    y1 = y1-m; %detrended y1
    snr=var(raw)/sd;
    % save new normalization constants
    M2(i)=mean(y1);
    S2(i)=std(y1);
    y1 = (y1 )/std(y1); % mean normalised
    detrendData=[detrendData; bring_to_size(y1',[1,numel(time)],NaN)];
    % fit OU and OUoscillatory models
    [LLR,LL1,LL2,par1,par2,xd,md]  = fitDataLLR1(x,y1,1/snr);
    par0TOT(i,:) = par0; % background
    par1TOT(i,:) = par1; % OU
    par2TOT(i,:) = par2; % OUosc
    LLRTOT(i) = LLR;
    LL1TOT(i)=LL1;
    LL2TOT(i)=LL2;
    dfit(i).x=x;
    dfit(i).xd=xd;
    dfit(i).Raw=raw;
    dfit(i).RawOsc=y1;
    dfit(i).M1=M1(i);
    dfit(i).M2=M2(i);
    dfit(i).S1=S1(i);
    dfit(i).S2=S2(i);
    dfit(i).M=m1*S1(i)+M1(i);
    dfit(i).m=md*S2(i)*S1(i)+M2(i);
    % show figure - comment out "showfigure" if don't want
    showfigure1(x,m,raw,y1,xd,md,M1(i),S1(i),S2(i),LLR,par2,par1,i);
    print(gcf(),[dirname,'/Cell',num2str(i)],'-dpng');
end
% save simulation
save([dirname,'/',strtok(fnames,'.') ,'nofdr.mat'])